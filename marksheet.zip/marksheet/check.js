
function Check()
{
var name = document.getElementById("n").value;	
var fname = document.getElementById("fn").value;	
var standard = document.getElementById("c").value;	
var roll = document.getElementById("r").value;	
var ip = document.getElementById("ip").value;	
var ebis = document.getElementById("ebis").value;	
var se = document.getElementById("se").value;	
var cns = document.getElementById("cns").value;	
var admt = document.getElementById("admt").value;	
var d1 = document.getElementById("display1");
var d2 = document.getElementById("display2");
var d3 = document.getElementById("display3");
var d4 = document.getElementById("display4");
var d5 = document.getElementById("display5");
var d6 = document.getElementById("display6");
var d7 = document.getElementById("display7");
var d8 = document.getElementById("display8");


var obtained = parseInt(ip) + parseInt(ebis) + parseInt(se) + parseInt(cns) + parseInt(admt);

var percentage = obtained * 100 / 500;

d1.innerHTML = "Your Name is:" + name;
d2.innerHTML = "Your Father Name is:" + fname;
d3.innerHTML = "Your Class is:" + standard;
d4.innerHTML = "Your Roll no is:" + roll;
d5.innerHTML = "Your obtained marks are: " + obtained;	
d6.innerHTML = "Your PErcentage is: " + percentage;	

if(percentage >= 80)
{
	d7.innerHTML = "Grade: A-1 !!";	
	
}
else if(percentage >= 70)
{
	d7.innerHTML = "Grade: A !!";	
	
}
else if(percentage >= 60)
{
	d7.innerHTML = "Grade: B !!";	
	
}
else if(percentage >= 50)
{
	d7.innerHTML = "Grade: C !!";	
	
}
else if(percentage >= 40)
{
	d7.innerHTML = "Grade: D !!";	
	
}
else if(percentage >= 33)
{
	d7.innerHTML = "Grade: E !!";	
	
}
else
{
	d7.innerHTML = "Grade: F (Fail) !!";	
	
}



if(percentage >= 35)
{
	d8.innerHTML = "Remarks: Pass!";	
	
}

else
{
	d8.innerHTML = "Remarks: Fail!";	
	
}

//var supply = 0;

// if(math < 33)
// {
	//supply++;
	// d10.innerHTML += "You have supply in maths !! <br/>";	
// }
// if(eng < 33)
// {
// //	supply++;
// 	d10.innerHTML += "You have supply in English !! <br/>";

// }
// if(chem < 33)
// {
// //	supply++;
// 	d10.innerHTML += "You have supply in Chemistry !! <br/>";
// }
// if(phy < 33)
// {
// //	supply++;
// 	d10.innerHTML += "You have supply in Physics !! <br/>";
// }
// if(urdu < 33)
// {
// //	supply++;
// 	d10.innerHTML += "You have supply in Urdu !! <br/>";
// }

// //d9.innerHTML = "Supply: " + supply;

 }